#pragma once

/// task 1
void task1();

/// task 2
void task2();

/// task 3
void task3();

/// task 4
void task4();

/// task 5
void task5();