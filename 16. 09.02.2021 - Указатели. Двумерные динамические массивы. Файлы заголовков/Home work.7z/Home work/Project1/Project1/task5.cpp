#include <iostream>

using namespace std;

void task5()
{

}